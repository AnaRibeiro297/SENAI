# -*- coding: UTF-8 -*-

print("Ola usuario, me da um lado L de um quadrado, eu lhe restaurar a aréa do mesmo")
l = float(input("Digite um lado"))
def area(l):
    area = l * l
    return area
print("A area do quadrado  é de", area(l))
