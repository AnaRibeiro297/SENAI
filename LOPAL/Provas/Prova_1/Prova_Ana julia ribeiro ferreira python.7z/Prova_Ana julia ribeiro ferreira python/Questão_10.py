#-*- coding: UTF-8 -*-

print("Ola usuario, me um valor de uma conta de um restaurante e eu vou calcular a taxa de serviço de 10 porcento, ou seja se o valor da conta seja superior a 200 reais, quando a taxa sera de 8 porcento")
n1=float(input("Me de um valor: "))
n2=float(input("Me de a taxa de serviço: "))
valor= n1*n2/2
print (n1+n2)
print("A taxa de serviço é de: ")
