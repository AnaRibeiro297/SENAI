#-*- coding: UTF-8 -*-4

print("Ola usuario, me um numero e vou clasificar os seguintes intervalos: menor que 10, entre 10 e 20 ou maior que 20")
n1=int(input("Digite o primeiro numero: "))
n2=int(input("Digite o segundo numero: "))
n3=int(input("Digite o terceiro nuemro: "))
if
