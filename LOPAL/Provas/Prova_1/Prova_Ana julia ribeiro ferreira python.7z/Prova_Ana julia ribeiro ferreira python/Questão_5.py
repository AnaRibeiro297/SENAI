#-*- coding: UTF-8 -*-

print("Ola usuario, me de um salario que calcule o bonus de 15 porcento e se o salario for inteiro a 1500 reais ou um bonus de 10 porcento caso contrario")
n1= float(input("Digite o seu salario: "))
n2= float(input("Digite o bonus: "))
salario= n1 * n2 + n2/100

print("O numero real representado do salario é: ",salario)

