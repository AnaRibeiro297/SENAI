#-*- coding: UTF-8 -*-

print("Ola usuario, me um numero inteiro que lhe informarei se ele é positivo ou negativo")
n1= int(input("Digite o primeiro numero: "))
positivo= n1
negativo= n1
while n1 >=n1 and n1 <=n1:
    if n1 >=2:
        print (n1)
        n1= int(input("Digite o segundo numero: "))
        if n1 <=2:
            print(n1)
           
print("O primeiro numero é: ",positivo)
print("O segundo numero é: ",negativo)
