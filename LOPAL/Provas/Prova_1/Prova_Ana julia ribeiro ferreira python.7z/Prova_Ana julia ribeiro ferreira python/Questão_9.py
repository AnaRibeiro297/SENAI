#-*- coding: UTF-8 -*-

print("Ola usuario, me de o comprimento dos tres lados de um triangulo e vou lhe informar se ele é equilatero mais todos os lados iguais")
n=int(input("Me de o primeiro lado: "))
n2=int(input("Me de o segundo lado: "))
n3=int(input("Me de o terceiro lado: "))
lados= 0
if lados <=3:
       for i in range(n, n2, n3):
           print("Os lados são equilátero: ")
           print("Os lados não são equiláteros: ")
