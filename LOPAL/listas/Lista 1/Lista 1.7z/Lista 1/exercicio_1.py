#-*- coding: UTF-8 -*-

print("Olá usuario, digite dois numeros e eu lhe trarei o resultado. Caso ele seja maior que 20, somarei mais 8. Se ele for menor ou igual a 20, irei subtrair por 5.")

n1=float(input("Digite o primeiro valor: "))
n2=float(input("Digite o segundo valor: "))
soma= n1 + n2

if soma>20:
    print("O resultado da sua soma é: " ,soma+8)
else:
    print("O resultado da sua soma é: ",soma-5)













    
