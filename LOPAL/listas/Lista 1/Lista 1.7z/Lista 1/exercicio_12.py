#-*- coding: UTF-8 -*-

print("ola usuario, me de dois numero inteiros, e vou lhe dizer se eles fiquem em ordem crescente")
n1= int(input("Digite um numero"))
n2= int(input("Digite outro numero"))

if n1 > n2:
        B = n1
        A = n2
        print("O numero', é menor")
        print("O numero', é maior")
elif num < num2:
     A = num
     B = num2
     print('O número', A, 'é menor')
     print("O número", B, "é maior")
