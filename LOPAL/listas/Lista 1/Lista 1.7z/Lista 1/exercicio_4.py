#-*- coding: UTF-8 -*-

print("Me de um valores e eu lhe direi se ele é par ou impar")

n1= int(input("Digite o valor: "))

if n1 % 2==0:
    print("Seu numero é par")
else:
    print("Seu nuemro éimpar")
    
