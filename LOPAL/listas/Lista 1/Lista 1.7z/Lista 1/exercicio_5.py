#-*- coding: UTF-8 -*-

print("Me de um valor e vou te dizer se é ou não multiplo de 3")

n1= float(input("Digite um numero: "))

if n1 % 3 ==0:
    print("Seu numero é multiplo de 3")
else:
    print("Seu numero não é multiplo de 3")
