#-*- coding: UTF-8 -*-

print("Me de numeros inteiros e eu lhe direi se eles sao divisiveis")

A= int(input("Digite seu valor: "))
B= int(input("Digite seu valor: "))

if A % B==0:
    print("Seus numeros são divisiveis")
else:
    print("Seus nuemros nao são divisiveis")
    
