#-*- coding: UTF-8 -*-

print("Me de dois numeros e vou lhe dizer qual sera o maior")

n1= int(input("Digite o primeiro numero"))
n2= int(input("Digite o segundo numero"))

if n1>n2:
    print("Esse é o maior")
else:
    print("O segundo valor é maior")
