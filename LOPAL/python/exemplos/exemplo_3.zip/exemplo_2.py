# -*- coding: UTF-8 -*-

fim = int(input("Defina o valor final para quatidade de repetições: "))

cont = 1

while cont <= fim:
    print(cont)
    #cont+=1
    cont = cont +1
