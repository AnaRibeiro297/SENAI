# -*- coding: UTF-8 -*-

fim = int(input("Digite o último número a imprimir: "))
x = 0
while x <= fim:
    if x % 2 == 0:
        print(x)
        x = x + 2
