# -*- coding: UTF-8 -*-

n = int(input("Tabuada de: "))
x = 1
while x <= 10:
    print (n, "x", x, "=", (n * x))
    x = x + 1
